<?php

namespace App\Http\Controllers\Gateway;

use App\Http\Controllers\Controller;
use App\Models\Gateway;
use App\Models\Withdrawal;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SuitPayController extends Controller
{
    /**
     * Processar saque via modal (recebe parâmetros na URL)
     * URL: /evopay/withdrawal/{id}/{action}
     */
    public function withdrawalFromModal($id, $action)
    {
        Log::info('=== EVOPAY: Iniciando processamento de saque ===', [
            'withdrawal_id' => $id,
            'action' => $action,
            'user_id' => auth()->id(),
            'url' => request()->fullUrl()
        ]);

        try {
            $withdrawal = Withdrawal::with('user')->find($id);
            
            if (!$withdrawal) {
                Log::error('EvoPay: Saque não encontrado', ['id' => $id]);
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'Saque não encontrado');
            }

            if ($withdrawal->status == 1) {
                Log::warning('EvoPay: Saque já processado', ['withdrawal_id' => $withdrawal->id]);
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'Este saque já foi processado');
            }

            // Buscar credenciais do gateway
            $gateway = Gateway::first();
            
            if (!$gateway || !$this->resolveEvoPayToken($gateway)) {
                Log::error('EvoPay: Gateway não configurado');
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'Gateway não configurado corretamente');
            }

            // Validar chave PIX do destinatário (usuário)
            if (!$withdrawal->pix_key) {
                Log::error('EvoPay: Chave PIX não informada', ['withdrawal_id' => $withdrawal->id]);
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'Chave PIX do usuário não informada');
            }

            // ============================================
            // OBTER DADOS DO USUÁRIO DO BANCO DE DADOS
            // ============================================
            $userName = $withdrawal->user->name ?? 'Usuário';
            
            // Tentar usar o CPF da tabela withdrawals, senão tentar a chave PIX
            $userCpf = $withdrawal->cpf ?? null;
            
            // Se não tiver CPF e a chave PIX for CPF/documento, usar ela
            if (empty($userCpf) && $withdrawal->pix_type === 'document') {
                $userCpf = $withdrawal->pix_key;
            }
            
            // Limpar CPF (remover pontos, traços)
            $userCpf = preg_replace('/[^0-9]/', '', $userCpf);
            
            if (empty($userCpf) || strlen($userCpf) != 11) {
                Log::error('EvoPay: CPF inválido ou não informado', [
                    'withdrawal_id' => $withdrawal->id,
                    'cpf' => $userCpf,
                    'pix_key' => $withdrawal->pix_key,
                    'pix_type' => $withdrawal->pix_type
                ]);
                
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'CPF do usuário não encontrado ou inválido');
            }

            Log::info('EvoPay: Dados do usuário obtidos', [
                'user_id' => $withdrawal->user_id,
                'name' => $userName,
                'cpf' => substr($userCpf, 0, 3) . '***' . substr($userCpf, -2) // Log parcial por segurança
            ]);
            // ============================================

            $postData = [
                'amount' => floatval($withdrawal->amount),
                'callbackUrl' => url('/api/evopay/webhook'),
                'pixKey' => $withdrawal->pix_key,
                'pixType' => $this->resolvePixType($withdrawal->pix_type, $withdrawal->pix_key),
                'metadata' => [
                    'withdrawal_id' => $withdrawal->id,
                ],
            ];

            Log::info('EvoPay: Enviando requisição de transferência', [
                'withdrawal_id' => $withdrawal->id,
                'amount' => $withdrawal->amount,
                'pix_key_destino' => $withdrawal->pix_key,
            ]);

            $responseData = $this->requestEvoPay($gateway, 'post', [
                '/withdraw',
            ], $postData);

            Log::info('EvoPay: Resposta da API recebida', [
                'response_data' => $responseData
            ]);

            if (!empty($responseData)) {
                $transactionId = $this->extractTransactionId($responseData);
                $externalId = $this->extractExternalId($responseData, $transactionId);
                $status = $this->extractStatus($responseData) ?? 'PENDING';
                $message = $responseData['message'] ?? 'Transferência processada';
                
                $withdrawal->update([
                    'status' => ($this->isCompletedStatus($status)) ? 1 : 0,
                    'bank_info' => json_encode([
                        'transaction_id' => $transactionId,
                        'external_id' => $externalId,
                        'status' => $status,
                        'message' => $message,
                        'pix_key' => $withdrawal->pix_key,
                        'amount' => $withdrawal->amount,
                        'processed_at' => now()->format('Y-m-d H:i:s'),
                        'processed_by' => auth()->user()->name ?? 'Sistema'
                    ])
                ]);

                Log::info('EvoPay: Saque PROCESSADO ✅', [
                    'withdrawal_id' => $withdrawal->id,
                    'transaction_id' => $transactionId,
                    'external_id' => $externalId,
                    'status' => $status,
                    'amount' => $withdrawal->amount,
                    'pix_key_destino' => $withdrawal->pix_key
                ]);

                return redirect()
                    ->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('success', 'Saque processado! Status: ' . $status . ' | ID: ' . $transactionId);
            }

            $errorMessage = $responseData['message'] ?? 'Erro ao processar transferência';
            
            Log::error('EvoPay: ERRO ao processar transferência', [
                'withdrawal_id' => $withdrawal->id,
                'error_message' => $errorMessage,
                'full_response' => $responseData,
            ]);

            return redirect()
                ->route('filament.admin.resources.todos-saques-historico.index')
                ->with('error', 'Erro EvoPay: ' . $errorMessage);

        } catch (\Exception $e) {
            Log::error('EvoPay: Exception capturada', [
                'error' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'trace' => $e->getTraceAsString(),
                'withdrawal_id' => $id ?? null
            ]);

            return redirect()
                ->route('filament.admin.resources.todos-saques-historico.index')
                ->with('error', 'Erro: ' . $e->getMessage());
        }
    }

    /**
     * Processar saque via query params (backup)
     */
    public function withdrawal(Request $request)
    {
        $withdrawalId = $request->input('id');
        
        Log::info('EvoPay: Redirecionando para método principal', [
            'id' => $withdrawalId
        ]);
        
        return $this->withdrawalFromModal($withdrawalId, 'user');
    }

    /**
     * Cancelar saque via modal
     */
    public function cancelWithdrawalFromModal($id, $action)
    {
        Log::info('=== EVOPAY: Iniciando cancelamento de saque ===', [
            'withdrawal_id' => $id,
            'action' => $action,
            'user_id' => auth()->id()
        ]);

        try {
            $withdrawal = Withdrawal::with('user')->find($id);
            
            if (!$withdrawal) {
                Log::error('EvoPay: Saque não encontrado para cancelamento', ['id' => $id]);
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'Saque não encontrado');
            }

            if ($withdrawal->status == 1) {
                Log::warning('EvoPay: Tentativa de cancelar saque já processado', [
                    'withdrawal_id' => $withdrawal->id
                ]);
                return redirect()->route('filament.admin.resources.todos-saques-historico.index')
                    ->with('error', 'Saque já foi pago, não pode ser cancelado');
            }

            // Devolver saldo ao usuário
            $withdrawal->user->increment('balance', $withdrawal->amount);

            $withdrawal->update([
                'status' => 2,
                'bank_info' => json_encode([
                    'cancelled_at' => now()->format('Y-m-d H:i:s'),
                    'cancelled_by' => auth()->user()->name ?? 'Sistema',
                    'amount_returned' => $withdrawal->amount
                ])
            ]);

            Log::info('EvoPay: Saque CANCELADO ✅', [
                'withdrawal_id' => $withdrawal->id,
                'amount_returned' => $withdrawal->amount,
                'user_id' => $withdrawal->user_id
            ]);

            return redirect()
                ->route('filament.admin.resources.todos-saques-historico.index')
                ->with('success', 'Saque cancelado! R$ ' . number_format($withdrawal->amount, 2, ',', '.') . ' devolvido ao usuário');

        } catch (\Exception $e) {
            Log::error('EvoPay: Erro ao cancelar saque', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'withdrawal_id' => $id ?? null
            ]);

            return redirect()
                ->route('filament.admin.resources.todos-saques-historico.index')
                ->with('error', 'Erro ao cancelar: ' . $e->getMessage());
        }
    }

    /**
     * Cancelar saque via query params (backup)
     */
    public function cancelWithdrawal(Request $request)
    {
        $withdrawalId = $request->input('id');
        
        Log::info('EvoPay: Redirecionando para método de cancelamento principal', [
            'id' => $withdrawalId
        ]);
        
        return $this->cancelWithdrawalFromModal($withdrawalId, 'user');
    }

    /**
     * ═══════════════════════════════════════════════════════════════
     * MÉTODO ANTIGO: Verificar status por token (manter compatibilidade)
     * ═══════════════════════════════════════════════════════════════
     */
    public function checkTransactionStatusByToken(Request $request)
    {
        try {
            $token = $request->bearerToken();
            
            Log::info('Verificando status da transação por token', [
                'has_token' => !empty($token),
                'user_id' => auth()->id()
            ]);
            
            if (!$token) {
                return response()->json([
                    'success' => false,
                    'message' => 'Token não fornecido'
                ], 401);
            }
            
            // Buscar transação pelo user logado
            $transaction = Transaction::where('user_id', auth()->id())
                ->orderBy('id', 'desc')
                ->first();
            
            if (!$transaction) {
                return response()->json([
                    'success' => false,
                    'message' => 'Nenhuma transação encontrada'
                ], 404);
            }
            
            return response()->json([
                'success' => true,
                'status' => $transaction->status,
                'transaction_id' => $transaction->id,
                'amount' => $transaction->price
            ], 200);
            
        } catch (\Exception $e) {
            Log::error('Erro ao verificar status por token', [
                'error' => $e->getMessage()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao verificar status'
            ], 500);
        }
    }

    /**
     * ═══════════════════════════════════════════════════════════════
     * NOVO MÉTODO: Verificar Pagamento PIX
     * Chamado pelo botão "Já Paguei" no frontend
     * ═══════════════════════════════════════════════════════════════
     */
    public function checkPayment(Request $request)
    {
        try {
            $qrcode = $request->input('qrcode');
            
            Log::info('Verificando pagamento PIX via botão', [
                'qrcode_length' => strlen($qrcode),
                'user_id' => auth()->id()
            ]);
            
            if (empty($qrcode)) {
                return response()->json([
                    'success' => false,
                    'paid' => false,
                    'message' => 'Código PIX não informado'
                ], 400);
            }
            
            // Buscar transação pelo QR Code
            $transaction = Transaction::where(function($query) use ($qrcode) {
                $query->where('qrcode_url', $qrcode)
                      ->orWhere('qrcode_pix', $qrcode);
            })
            ->where('user_id', auth()->id())
            ->orderBy('id', 'desc')
            ->first();
            
            if (!$transaction) {
                Log::warning('Transação não encontrada', [
                    'qrcode_length' => strlen($qrcode),
                    'user_id' => auth()->id()
                ]);
                
                return response()->json([
                    'success' => false,
                    'paid' => false,
                    'message' => 'Transação não encontrada'
                ], 404);
            }
            
            Log::info('Transação encontrada', [
                'transaction_id' => $transaction->id,
                'status' => $transaction->status,
                'amount' => $transaction->price,
                'external_id' => $transaction->external_id
            ]);
            
            // Verificar status da transação
            if ($transaction->status == 1) {
                // JÁ ESTÁ PAGO!
                Log::info('✅ Pagamento JÁ CONFIRMADO!', [
                    'transaction_id' => $transaction->id,
                    'user_id' => $transaction->user_id,
                    'amount' => $transaction->price
                ]);
                
                return response()->json([
                    'success' => true,
                    'paid' => true,
                    'message' => 'Pagamento confirmado!',
                    'transaction_id' => $transaction->id,
                    'amount' => $transaction->price
                ], 200);
            }
            
            $gateway = Gateway::first();
            
            if (!$gateway) {
                return response()->json([
                    'success' => false,
                    'paid' => false,
                    'message' => 'Gateway não configurado'
                ], 500);
            }
            
            $external_id = $transaction->payment_id ?? $transaction->external_id;
            
            if ($external_id) {
                Log::info('Consultando API EvoPay', [
                    'external_id' => $external_id
                ]);
                
                try {
                    $responseData = $this->requestEvoPay($gateway, 'get', [
                        '/pix?id=' . urlencode($external_id),
                    ]);
                    
                    Log::info('Resposta API EvoPay', [
                        'response' => $responseData
                    ]);
                    
                    if (!empty($responseData) && $this->isCompletedStatus($this->extractStatus($responseData) ?? '')) {
                        Log::info('✅ PAGAMENTO CONFIRMADO pela API!', [
                            'transaction_id' => $transaction->id,
                            'external_id' => $external_id
                        ]);
                        
                        \App\Traits\Gateways\SuitpayTrait::finalizePaymentViaWebhook($external_id);
                        
                        return response()->json([
                            'success' => true,
                            'paid' => true,
                            'message' => 'Pagamento confirmado!',
                            'transaction_id' => $transaction->id,
                            'amount' => $transaction->price
                        ], 200);
                    }
                    
                } catch (\Exception $e) {
                    Log::error('Erro ao consultar API EvoPay', [
                        'error' => $e->getMessage()
                    ]);
                }
            }
            
            // Ainda não foi pago
            return response()->json([
                'success' => true,
                'paid' => false,
                'message' => 'Pagamento ainda não identificado',
                'transaction_id' => $transaction->id
            ], 200);
            
        } catch (\Exception $e) {
            Log::error('Erro ao verificar pagamento', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'paid' => false,
                'message' => 'Erro ao verificar pagamento: ' . $e->getMessage()
            ], 500);
        }
    }

    public function webhook(Request $request)
    {
        try {
            $data = $request->all();
            
            Log::info('EvoPay Webhook recebido', ['data' => $data]);

            if (!$data) {
                return response()->json(['status' => 'error'], 400);
            }

            if (isset($data['requestBody'])) {
                $data = $data['requestBody'];
                Log::info('EvoPay Webhook: Extraído de requestBody', ['data' => $data]);
            }

            $transactionId = $this->extractTransactionId($data) ?? $this->extractExternalId($data);
            $status = $this->extractStatus($data) ?? 'PENDING';

            if ($this->isCompletedStatus($status) && $transactionId) {
                $transaction = Transaction::where(function($query) use ($transactionId) {
                    $query->where('payment_id', $transactionId)
                          ->orWhere('external_id', $transactionId);
                })->where('status', 0)->first();

                if ($transaction) {
                    $result = \App\Traits\Gateways\SuitpayTrait::finalizePaymentViaWebhook($transaction->external_id);
                    if ($result) {
                        Log::info('EvoPay Webhook: Depósito confirmado ✅', [
                            'transaction_id' => $transactionId,
                            'external_id' => $transaction->external_id
                        ]);
                    }
                } else {
                    Log::warning('EvoPay Webhook: Transação não encontrada no banco', [
                        'transaction_id' => $transactionId
                    ]);
                }

                $withdrawals = Withdrawal::whereRaw(
                    "JSON_EXTRACT(bank_info, '$.transaction_id') = ? OR JSON_EXTRACT(bank_info, '$.external_id') = ?",
                    [$transactionId, $transactionId]
                )->get();

                foreach ($withdrawals as $withdrawal) {
                    $bankInfo = json_decode($withdrawal->bank_info, true) ?? [];
                    $bankInfo['webhook_confirmed'] = now()->format('Y-m-d H:i:s');
                    $bankInfo['webhook_transaction_id'] = $transactionId;
                    $bankInfo['webhook_status'] = $status;

                    $withdrawal->update([
                        'status' => 1,
                        'bank_info' => json_encode($bankInfo)
                    ]);
                }
            }

            return response()->json(['status' => 'success'], 200);

        } catch (\Exception $e) {
            Log::error('EvoPay Webhook: Erro ao processar', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json(['status' => 'error'], 500);
        }
    }

    private function resolveEvoPayToken(Gateway $gateway): ?string
    {
        $token = trim((string) ($gateway->suitpay_cliente_secret ?? ''));
        if (empty($token)) {
            $token = trim((string) ($gateway->suitpay_cliente_id ?? ''));
        }

        $token = preg_replace('/^Bearer\s+/i', '', $token);

        return $token ?: null;
    }

    private function resolveEvoPayBaseUrl(?Gateway $gateway): string
    {
        $base = trim((string) ($gateway?->suitpay_uri ?? ''));
        if (empty($base)) {
            $base = 'https://pix.evopay.cash/v1';
        }
        return rtrim($base, '/');
    }

    private function requestEvoPay(Gateway $gateway, string $method, array $paths, array $payload = []): array
    {
        $token = $this->resolveEvoPayToken($gateway);
        if (empty($token)) {
            return [];
        }

        $base = $this->resolveEvoPayBaseUrl($gateway);
        foreach ($paths as $path) {
            $url = $base . '/' . ltrim($path, '/');
            try {
                $request = Http::withHeaders(['API-Key' => $token])->acceptJson()->timeout(30);
                $response = strtolower($method) === 'get'
                    ? $request->get($url)
                    : $request->asJson()->post($url, $payload);

                if ($response->successful()) {
                    return $response->json() ?? [];
                }
            } catch (\Throwable $e) {
                Log::warning('Falha na requisição EvoPay', [
                    'url' => $url,
                    'error' => $e->getMessage()
                ]);
            }
        }

        return [];
    }

    private function extractTransactionId(array $data): ?string
    {
        return data_get($data, 'transactionId')
            ?? data_get($data, 'id')
            ?? data_get($data, 'txid')
            ?? data_get($data, 'data.transactionId')
            ?? data_get($data, 'data.id');
    }

    private function extractExternalId(array $data, ?string $fallback = null): ?string
    {
        return data_get($data, 'external_id')
            ?? data_get($data, 'externalId')
            ?? data_get($data, 'reference')
            ?? data_get($data, 'reference_code')
            ?? data_get($data, 'end_to_end_id')
            ?? data_get($data, 'e2eId')
            ?? data_get($data, 'data.external_id')
            ?? data_get($data, 'data.reference')
            ?? $fallback;
    }

    private function extractStatus(array $data): ?string
    {
        return data_get($data, 'status')
            ?? data_get($data, 'transaction.status')
            ?? data_get($data, 'data.status');
    }

    private function isCompletedStatus(string $status): bool
    {
        return in_array(strtoupper($status), ['COMPLETED', 'PAID', 'SUCCESS', 'APPROVED'], true);
    }

    private function resolvePixType(?string $pixType, ?string $pixKey): string
    {
        $type = strtolower((string) $pixType);
        if (in_array($type, ['cpf', 'email', 'phone', 'random'], true)) {
            return $type;
        }

        if ($type === 'document') {
            return 'cpf';
        }

        $key = preg_replace('/\s+/', '', (string) $pixKey);
        $digits = preg_replace('/\D+/', '', (string) $pixKey);

        if (filter_var($key, FILTER_VALIDATE_EMAIL)) {
            return 'email';
        }

        if (strlen($digits) === 11) {
            return 'cpf';
        }

        if (strlen($digits) >= 10 && strlen($digits) <= 13) {
            return 'phone';
        }

        return 'random';
    }
}
