<?php

namespace App\Traits\Gateways;

use App\Models\AffiliateHistory;
use App\Models\Deposit;
use App\Models\GamesKey;
use App\Models\Gateway;
use App\Models\Setting;
use App\Models\SuitPayPayment;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use App\Notifications\NewDepositNotification;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Core as Helper;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

trait SuitpayTrait
{
    protected static string $uri;
    protected static string $clienteId;
    protected static string $clienteSecret;

    private static function generateCredentials()
    {
        $setting = Gateway::first();
        if (!empty($setting)) {
            self::$uri = $setting->getAttributes()['suitpay_uri'];
            self::$clienteId = $setting->getAttributes()['suitpay_cliente_id'];
            self::$clienteSecret = $setting->getAttributes()['suitpay_cliente_secret'];
        }
    }

    public static function requestQrcode($request)
    {
        try {
            $setting = Helper::getSetting();
            $validator = Validator::make($request->all(), [
                'amount' => ['required', 'numeric', 'min:' . $setting->min_deposit, 'max:' . $setting->max_deposit],
                'cpf'    => ['required', 'string', 'max:255'],
            ]);

            if ($validator->fails()) {
                return response()->json($validator->errors(), 400);
            }

            self::generateCredentials();
            $token = self::resolveToken();
            if (empty($token)) {
                return response()->json(['error' => 'Token EvoPay não configurado'], 500);
            }

            $payload = [
                'amount' => (float) $request->input('amount'),
                'callbackUrl' => url('/api/evopay/webhook'),
                'payerName' => auth('api')->user()->name,
                'payerDocument' => Helper::soNumero($request->input('cpf')),
                'payerEmail' => auth('api')->user()->email,
                'metadata' => [
                    'user_id' => auth('api')->id(),
                ],
            ];

            $result = self::requestEvoPay('post', [
                '/pix',
            ], $payload);

            if (!$result) {
                return response()->json(['error' => 'Falha ao gerar cobrança Pix na EvoPay'], 500);
            }

            $responseData = $result['data'] ?? [];
            $transactionId = self::extractTransactionId($responseData);
            $externalId = self::extractExternalId($responseData, $transactionId);
            $qrcode = self::extractQrCode($responseData);

            if (!$transactionId || !$qrcode) {
                return response()->json(['error' => 'Resposta inválida da EvoPay'], 500);
            }

            DB::transaction(function () use ($transactionId, $request, $externalId) {
                self::generateTransaction($transactionId, $request->input('amount'), $externalId);
                self::generateDeposit($transactionId, $request->input('amount'), $externalId);
            });

            return response()->json([
                'status' => true,
                'transactionId' => $transactionId,
                'qrcode' => $qrcode,
                'externalId' => $externalId
            ]);

        } catch (\Exception $e) {
            Log::error('[EvoPay] Erro ao solicitar QR Code', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Erro interno'], 500);
        }
    }

    public static function consultStatusTransaction()
    {
        self::generateCredentials();
        $token = self::resolveToken();
        if (empty($token)) {
            return response()->json(['message' => 'Token EvoPay não configurado'], 200);
        }

        try {
            $transactions = Transaction::where('status', '!=', 1)
                ->latest()
                ->take(5)
                ->get();

            if ($transactions->isEmpty()) {
                return response()->json(['message' => 'Nenhuma transação pendente'], 200);
            }

            $validTransactions = [];
            foreach ($transactions as $transaction) {
                $timeDifference = now()->diffInMinutes($transaction->updated_at);

                if ($timeDifference <= 10) {
                    $validTransactions[] = $transaction->payment_id ?: $transaction->external_id;
                }
            }

            if (empty($validTransactions)) {
                return response()->json(['message' => 'Nenhuma transação recente'], 200);
            }

            $responses = [];
            foreach ($validTransactions as $externalId) {
                $result = self::requestEvoPay('get', [
                    '/pix?id=' . urlencode($externalId),
                ]);

                if (!$result) {
                    $responses[$externalId] = ['status' => 'pendente'];
                    continue;
                }

                $statusData = $result['data'] ?? [];
                $transactionStatus = self::extractStatus($statusData);
                if (!empty($transactionStatus)) {
                    if (self::isStatusCompleted($transactionStatus)) {
                        self::finalizePayment($externalId);
                    }
                    $responses[$externalId] = ['status' => $transactionStatus];
                } else {
                    $responses[$externalId] = ['status' => 'pendente'];
                }
            }

            return response()->json($responses);
        } catch (\Exception $e) {
            Log::critical('[EvoPay] Erro crítico', [
                'erro' => $e->getMessage()
            ]);
            return response()->json(['error' => 'Erro interno'], 500);
        }
    }

    public static function finalizePaymentViaWebhook(string $externalId): bool
    {
        Log::info('[EvoPay Webhook] Finalizando pagamento', ['external_id' => $externalId]);
        return self::finalizePayment($externalId);
    }

    public static function finalizePayment($externalId) : bool
    {
        Log::info("[EvoPay] Iniciando finalização do pagamento com external_id: $externalId");
        $transaction = Transaction::where('external_id', $externalId)->where('status', 0)->first();
        if (!$transaction) {
            Log::error("[EvoPay] Transação não encontrada para o external_id: $externalId");
            return false;
        }
        Log::info('[EvoPay] Transação encontrada', ['id' => $transaction->id]);

        $setting = Helper::getSetting();
        $user = User::find($transaction->user_id);
        Log::info('[EvoPay] Usuário encontrado', ['id' => $user->id]);

        $wallet = Wallet::where('user_id', $transaction->user_id)->first();
        if (!$wallet) {
            Log::error('[EvoPay] Carteira não encontrada');
            return false;
        }
        Log::info('[EvoPay] Carteira encontrada');

        $checkTransactions = Transaction::where('user_id', $transaction->user_id)
            ->where('status', 1)
            ->count();
        Log::info("[EvoPay] Transações anteriores: $checkTransactions");

        if ($checkTransactions == 0) {
            $bonus = Helper::porcentagem_xn($setting->initial_bonus, $transaction->price);
            Log::info("[EvoPay] Pagando bônus inicial: $bonus");
            $wallet->increment('balance_bonus', $bonus);
            $wallet->update(['balance_bonus_rollover' => $bonus * $setting->rollover]);
        }

        $wallet->update(['balance_deposit_rollover' => $transaction->price * intval($setting->rollover_deposit)]);
        Log::info('[EvoPay] Aplicando rollover ao depósito');

        Helper::payBonusVip($wallet, $transaction->price);
        Log::info('[EvoPay] Pagando bônus VIP');

        if ($wallet->increment('balance', $transaction->price)) {
            Log::info('[EvoPay] Saldo do usuário atualizado');

            if ($transaction->update(['status' => 1])) {
                Log::info("[EvoPay] Status da transação atualizado para 'pago'");

                $deposit = Deposit::where('external_id', $externalId)->where('status', 0)->first();
                if (!empty($deposit)) {
                    Log::info('[EvoPay] Depósito encontrado', ['id' => $deposit->id]);

                    $affHistoryCPA = AffiliateHistory::where('user_id', $user->id)
                        ->where('commission_type', 'cpa')
                        ->where('status', 0)
                        ->first();
                    if (!empty($affHistoryCPA)) {
                        Log::info('[EvoPay] Verificando histórico de CPA');

                        $sponsorCpa = User::find($user->inviter);
                        if (!empty($sponsorCpa)) {
                            Log::info('[EvoPay] Sponsor encontrado para CPA', ['id' => $sponsorCpa->id]);
                            if ($affHistoryCPA->deposited_amount >= $sponsorCpa->affiliate_baseline || $deposit->amount >= $sponsorCpa->affiliate_baseline) {
                                $walletCpa = Wallet::where('user_id', $affHistoryCPA->inviter)->first();
                                if (!empty($walletCpa)) {
                                    $walletCpa->increment('refer_rewards', $sponsorCpa->affiliate_cpa);
                                    $affHistoryCPA->update(['status' => 1, 'commission_paid' => $sponsorCpa->affiliate_cpa]);
                                    Log::info('[EvoPay] CPA pago ao sponsor', ['sponsor_id' => $sponsorCpa->id]);
                                }
                            } else {
                                $affHistoryCPA->update(['deposited_amount' => $transaction->price]);
                                Log::info('[EvoPay] Valor depositado atualizado no CPA');
                            }
                        }
                    }

                    if ($deposit->update(['status' => 1])) {
                        Log::info('[EvoPay] Depósito marcado como pago ✅');

                        $admins = User::where('role_id', 0)->get();
                        foreach ($admins as $admin) {
                            $admin->notify(new NewDepositNotification($user->name, $transaction->price));
                            Log::info('[EvoPay] Notificação enviada ao admin', ['admin_id' => $admin->id]);
                        }
                    }
                }
            }
        } else {
            Log::error('[EvoPay] Erro ao atualizar o saldo do usuário');
            return false;
        }

        return true;
    }

    private static function generateDeposit($idTransaction, $amount, $externalId)
    {
        $userId = auth('api')->user()->id;
        $wallet = Wallet::where('user_id', $userId)->first();

        Deposit::create([
            'payment_id'=> $idTransaction,
            'user_id'   => $userId,
            'amount'    => $amount,
            'type'      => 'pix',
            'currency'  => $wallet->currency,
            'symbol'    => $wallet->symbol,
            'status'    => 0,
            'external_id' => $externalId,
        ]);
    }

    private static function generateTransaction($idTransaction, $amount, $externalId)
    {
        $setting = Helper::getSetting();

        Transaction::create([
            'payment_id' => $idTransaction,
            'user_id' => auth('api')->user()->id,
            'payment_method' => 'pix',
            'price' => $amount,
            'currency' => $setting->currency_code,
            'status' => 0,
            'external_id' => $externalId,
        ]);
    }

    public static function pixCashOut(array $array): bool
    {
        self::generateCredentials();
        $token = self::resolveToken();
        if (empty($token)) {
            return false;
        }

        $result = self::requestEvoPay('post', [
            '/withdraw',
        ], [
            'amount' => (float) $array['amount'],
            'callbackUrl' => url('/api/evopay/webhook'),
            'pixKey' => $array['pix_key'],
            'pixType' => self::resolvePixType($array['pix_type'] ?? null, $array['pix_key']),
            'metadata' => [
                'suitpayment_id' => $array['suitpayment_id'] ?? null,
            ],
        ]);

        if ($result) {
            $responseData = $result['data'] ?? [];
            $status = self::extractStatus($responseData);
            if (!empty($status) && in_array(strtoupper($status), ['COMPLETED', 'PENDING', 'WAITING_FOR_REFUND'])) {
                $suitPayPayment = SuitPayPayment::lockForUpdate()->find($array['suitpayment_id']);
                if (!empty($suitPayPayment)) {
                    $paymentId = self::extractTransactionId($responseData) ?? self::extractExternalId($responseData);
                    if ($suitPayPayment->update(['status' => 1, 'payment_id' => $paymentId])) {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return false;
    }

    private static function resolveToken(): ?string
    {
        $token = trim((string) (self::$clienteSecret ?? ''));
        if (empty($token)) {
            $token = trim((string) (self::$clienteId ?? ''));
        }
        $token = preg_replace('/^Bearer\s+/i', '', $token);
        return $token ?: null;
    }

    private static function baseUrl(): string
    {
        $base = trim((string) (self::$uri ?? ''));
        if (empty($base)) {
            $base = 'https://pix.evopay.cash/v1';
        }
        return rtrim($base, '/');
    }

    private static function requestEvoPay(string $method, array $paths, array $payload = []): ?array
    {
        $token = self::resolveToken();
        if (empty($token)) {
            return null;
        }

        foreach ($paths as $path) {
            $url = self::baseUrl() . '/' . ltrim($path, '/');
            try {
                $request = Http::withHeaders(['API-Key' => $token])
                    ->acceptJson()
                    ->timeout(30);

                $response = strtolower($method) === 'get'
                    ? $request->get($url)
                    : $request->asJson()->post($url, $payload);

                if ($response->successful()) {
                    return [
                        'url' => $url,
                        'data' => $response->json(),
                    ];
                }
            } catch (\Throwable $e) {
                Log::warning('[EvoPay] Falha na requisição', [
                    'url' => $url,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return null;
    }

    private static function extractTransactionId(array $data): ?string
    {
        return data_get($data, 'transactionId')
            ?? data_get($data, 'id')
            ?? data_get($data, 'txid')
            ?? data_get($data, 'data.transactionId')
            ?? data_get($data, 'data.id');
    }

    private static function extractExternalId(array $data, ?string $fallback = null): ?string
    {
        return data_get($data, 'external_id')
            ?? data_get($data, 'externalId')
            ?? data_get($data, 'reference')
            ?? data_get($data, 'reference_code')
            ?? data_get($data, 'end_to_end_id')
            ?? data_get($data, 'e2eId')
            ?? data_get($data, 'data.external_id')
            ?? data_get($data, 'data.reference')
            ?? $fallback;
    }

    private static function extractQrCode(array $data): ?string
    {
        return data_get($data, 'qrCodeText')
            ?? data_get($data, 'qrcode')
            ?? data_get($data, 'pix_copy_paste')
            ?? data_get($data, 'pixCode')
            ?? data_get($data, 'emv')
            ?? data_get($data, 'payload')
            ?? data_get($data, 'data.qrCodeText')
            ?? data_get($data, 'data.qrcode')
            ?? data_get($data, 'data.pix_copy_paste');
    }

    private static function extractStatus(array $data): ?string
    {
        return data_get($data, 'status')
            ?? data_get($data, 'transaction.status')
            ?? data_get($data, 'data.status');
    }

    private static function isStatusCompleted(string $status): bool
    {
        return in_array(strtoupper($status), ['COMPLETED', 'PAID', 'SUCCESS', 'APPROVED'], true);
    }

    private static function resolvePixType(?string $pixType, ?string $pixKey): string
    {
        $type = strtolower((string) $pixType);
        if (in_array($type, ['cpf', 'email', 'phone', 'random'], true)) {
            return $type;
        }

        if ($type === 'document') {
            return 'cpf';
        }

        $key = preg_replace('/\s+/', '', (string) $pixKey);
        $digits = preg_replace('/\D+/', '', (string) $pixKey);

        if (filter_var($key, FILTER_VALIDATE_EMAIL)) {
            return 'email';
        }

        if (strlen($digits) === 11) {
            return 'cpf';
        }

        if (strlen($digits) >= 10 && strlen($digits) <= 13) {
            return 'phone';
        }

        return 'random';
    }
}
